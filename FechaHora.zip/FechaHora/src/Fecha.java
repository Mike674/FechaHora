/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GX505DT
 */
public class Fecha {
    private  int dia;
    private int mes;
    private  int año;
    private int hora;
    private  int minuto;
    

}
